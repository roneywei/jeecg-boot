------------------------------------------------------------------------------
Beyond Compare 4
by Scooter Software                                    www.scootersoftware.com
------------------------------------------------------------------------------

1. 描述
-------
Beyond Compare是一个Windows平台上的文件和文件夹比较工具。使用该工具可以可视化和调整差异，
合并修改，同步文件夹。


2. 系统要求
-----------
该程序运行于：
- Windows XP
- Windows Server 2003，Windows Server 2003 x64
- Windows Vista，Windows Vista x64
- Windows Server 2008，Windows Server 2008 x64
- Windows 7，Windows 7 x64
- Windows Server 2008 R2
- Windows 8，Windows 8 x64
- Windows Server 2012
- Windows Server 2012 R2
- Windows 10，Windows 10 x64

我们的网站上也有Mac和Linux版本的程序。


3. 评估模式
-----------
你可以免费的评估Beyond Compare 30天（实际使用时间）。30天之后该程序需要一个许可证密钥才能继续工作。

有关购买或升级许可证的信息，请访问：
    http://www.scootersoftware.com/buynow


4. 联系人信息
-------------
如果你有问题，意见或建议，我们希望收到你的信息。如果要报告bug，你可以点击“帮助”菜单内的“支持”来获得程序设置的转储。
复制并粘贴设置信息到你的email中帮助我们追查到问题。

    Email:  support@scootersoftware.com 或 sales@scootersoftware.com
    网站:   http://www.scootersoftware.com/
